"""
Unified Code Graph
==================

Combines the structural relationships discovered by Code Guardian AI
into one graph representation.

Current sources:

    AST / project structure
    CFG
    Call Graph
    Dependency Graph
    Data Flow
    Def-Use
    Reaching Definitions
    Taint Analysis

The graph is intentionally framework-independent.

It does NOT depend on:
    - PyTorch
    - PyTorch Geometric
    - NetworkX

This keeps the analysis layer independent from the future ML layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ============================================================
# Edge Types
# ============================================================


class CodeGraphEdgeType(str, Enum):
    """
    Relationship types supported by the unified code graph.
    """

    CONTAINS = "contains"
    NESTS = "nests"

    HAS_CFG_NODE = "has_cfg_node"
    CONTROL_FLOW = "control_flow"

    CALLS = "calls"

    DEPENDS_ON = "depends_on"

    DEFINES = "defines"
    USES = "uses"
    DEF_USE = "def_use"

    TAINT_FLOW = "taint_flow"

    DATA_DEPENDENCY = "data_dependency"

    INHERITS = "inherits"
    OVERRIDES = "overrides"


# ============================================================
# Node
# ============================================================


@dataclass
class CodeGraphNode:
    """
    Represents one node in the unified code graph.

    Examples:

        file
        class
        function
        method
        cfg_node
        definition
        use
        variable
    """

    id: str
    node_type: str

    name: str | None = None

    file: str | None = None

    line: int | None = None

    function_id: str | None = None

    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """
        Convert node to a JSON-compatible dictionary.
        """

        result = {
            "id": self.id,
            "type": self.node_type,
        }

        if self.name is not None:
            result["name"] = self.name

        if self.file is not None:
            result["file"] = self.file

        if self.line is not None:
            result["line"] = self.line

        if self.function_id is not None:
            result["function_id"] = self.function_id

        if self.metadata:
            result["metadata"] = self.metadata

        return result


# ============================================================
# Edge
# ============================================================


@dataclass(frozen=True)
class CodeGraphEdge:
    """
    Represents a relationship between two graph nodes.
    """

    source: str

    target: str

    edge_type: CodeGraphEdgeType

    metadata: tuple[tuple[str, Any], ...] = ()

    def to_dict(self) -> dict[str, Any]:
        """
        Convert edge to a JSON-compatible dictionary.
        """

        return {
            "source": self.source,
            "target": self.target,
            "type": self.edge_type.value,
            "metadata": dict(self.metadata),
        }


# ============================================================
# Unified Graph
# ============================================================


class UnifiedCodeGraph:
    """
    Main graph structure.

    The graph maintains:

        nodes
        edges

    and provides helper methods for adding and querying them.
    """

    def __init__(self) -> None:

        self.nodes: dict[str, CodeGraphNode] = {}

        self.edges: list[CodeGraphEdge] = []

        # Fast duplicate detection.
        self._edge_keys: set[
            tuple[
                str,
                str,
                CodeGraphEdgeType,
                tuple[tuple[str, Any], ...],
            ]
        ] = set()

    # --------------------------------------------------------
    # Nodes
    # --------------------------------------------------------

    def add_node(
        self,
        node_id: str,
        node_type: str,
        name: str | None = None,
        file: str | None = None,
        line: int | None = None,
        function_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CodeGraphNode:
        """
        Add a node.

        If the node already exists, its metadata is updated.
        """

        if node_id in self.nodes:

            node = self.nodes[node_id]

            if name is not None:
                node.name = name

            if file is not None:
                node.file = file

            if line is not None:
                node.line = line

            if function_id is not None:
                node.function_id = function_id

            if metadata:
                node.metadata.update(metadata)

            return node

        node = CodeGraphNode(
            id=node_id,
            node_type=node_type,
            name=name,
            file=file,
            line=line,
            function_id=function_id,
            metadata=metadata or {},
        )

        self.nodes[node_id] = node

        return node

    # --------------------------------------------------------
    # Edges
    # --------------------------------------------------------

    def add_edge(
        self,
        source: str,
        target: str,
        edge_type: CodeGraphEdgeType | str,
        metadata: dict[str, Any] | None = None,
    ) -> CodeGraphEdge:
        """
        Add an edge.

        Duplicate edges are ignored.
        """

        if source not in self.nodes:
            raise ValueError(
                f"Source node does not exist: {source}"
            )

        if target not in self.nodes:
            raise ValueError(
                f"Target node does not exist: {target}"
            )

        if isinstance(edge_type, str):

            edge_type = CodeGraphEdgeType(edge_type)

        metadata_tuple = tuple(
            sorted(
                (metadata or {}).items(),
                key=lambda item: item[0],
            )
        )

        key = (
            source,
            target,
            edge_type,
            metadata_tuple,
        )

        if key in self._edge_keys:

            for edge in self.edges:

                if (
                    edge.source == source
                    and edge.target == target
                    and edge.edge_type == edge_type
                    and edge.metadata == metadata_tuple
                ):
                    return edge

        edge = CodeGraphEdge(
            source=source,
            target=target,
            edge_type=edge_type,
            metadata=metadata_tuple,
        )

        self.edges.append(edge)

        self._edge_keys.add(key)

        return edge

    # --------------------------------------------------------
    # Queries
    # --------------------------------------------------------

    def get_node(
        self,
        node_id: str,
    ) -> CodeGraphNode | None:
        """
        Return a node by ID.
        """

        return self.nodes.get(node_id)

    def get_edges_from(
        self,
        node_id: str,
    ) -> list[CodeGraphEdge]:
        """
        Return outgoing edges.
        """

        return [
            edge
            for edge in self.edges
            if edge.source == node_id
        ]

    def get_edges_to(
        self,
        node_id: str,
    ) -> list[CodeGraphEdge]:
        """
        Return incoming edges.
        """

        return [
            edge
            for edge in self.edges
            if edge.target == node_id
        ]

    def get_edges_by_type(
        self,
        edge_type: CodeGraphEdgeType | str,
    ) -> list[CodeGraphEdge]:
        """
        Return all edges of a particular type.
        """

        if isinstance(edge_type, str):
            edge_type = CodeGraphEdgeType(edge_type)

        return [
            edge
            for edge in self.edges
            if edge.edge_type == edge_type
        ]

    # --------------------------------------------------------
    # Statistics
    # --------------------------------------------------------

    def get_statistics(self) -> dict[str, Any]:
        """
        Return graph statistics.
        """

        node_types: dict[str, int] = {}

        for node in self.nodes.values():

            node_types[node.node_type] = (
                node_types.get(node.node_type, 0) + 1
            )

        edge_types: dict[str, int] = {}

        for edge in self.edges:

            edge_type = edge.edge_type.value

            edge_types[edge_type] = (
                edge_types.get(edge_type, 0) + 1
            )

        return {
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "node_types": node_types,
            "edge_types": edge_types,
        }

    # --------------------------------------------------------
    # Serialization
    # --------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """
        Convert the complete graph to a dictionary.
        """

        return {
            "nodes": [
                node.to_dict()
                for node in self.nodes.values()
            ],
            "edges": [
                edge.to_dict()
                for edge in self.edges
            ],
            "statistics": self.get_statistics(),
        }


# ============================================================
# Builder
# ============================================================


class UnifiedCodeGraphBuilder:
    """
    Builds a UnifiedCodeGraph from the existing Code Guardian
    analysis results.

    The builder is deliberately tolerant of different analyzer
    return formats so that existing analyzers do not need to be
    rewritten.
    """

    def __init__(self) -> None:

        self.graph = UnifiedCodeGraph()

    # --------------------------------------------------------
    # Generic helpers
    # --------------------------------------------------------

    @staticmethod
    def _safe_get(
        obj: Any,
        attribute: str,
        default: Any = None,
    ) -> Any:
        """
        Safely retrieve an attribute from an object.
        """

        if obj is None:
            return default

        if isinstance(obj, dict):
            return obj.get(attribute, default)

        return getattr(
            obj,
            attribute,
            default,
        )

    @staticmethod
    def _iter_items(
        value: Any,
    ):
        """
        Iterate over dictionary-like or iterable objects.
        """

        if value is None:
            return []

        if isinstance(value, dict):
            return value.items()

        try:
            return enumerate(value)
        except TypeError:
            return []

    # --------------------------------------------------------
    # File / function structure
    # --------------------------------------------------------

    def add_file(
        self,
        file_path: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Add a repository file node.
        """

        self.graph.add_node(
            node_id=file_path,
            node_type="file",
            name=file_path,
            file=file_path,
            metadata=metadata,
        )

        return file_path

    def add_function(
        self,
        function_id: str,
        file_path: str | None = None,
        function_name: str | None = None,
        line: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Add a function node.
        """

        self.graph.add_node(
            node_id=function_id,
            node_type="function",
            name=function_name or function_id,
            file=file_path,
            line=line,
            function_id=function_id,
            metadata=metadata,
        )

        if file_path:

            self.add_file(file_path)

            self.graph.add_edge(
                file_path,
                function_id,
                CodeGraphEdgeType.CONTAINS,
            )

        return function_id

    # --------------------------------------------------------
    # CFG
    # --------------------------------------------------------

    def add_cfg(
        self,
        function_id: str,
        cfg: Any,
    ) -> None:
        """
        Add CFG nodes and CONTROL_FLOW edges.
        """

        if cfg is None:
            return

        nodes = []

        get_nodes = getattr(
            cfg,
            "get_nodes",
            None,
        )

        if callable(get_nodes):

            nodes = get_nodes()

        elif hasattr(cfg, "nodes"):

            nodes = cfg.nodes

            if isinstance(nodes, dict):
                nodes = nodes.values()

        for cfg_node in nodes:

            node_id = self._safe_get(
                cfg_node,
                "id",
            )

            if node_id is None:
                continue

            graph_node_id = (
                f"{function_id}::cfg::{node_id}"
            )

            line = self._safe_get(
                cfg_node,
                "line",
            )

            node_type = self._safe_get(
                cfg_node,
                "node_type",
                "cfg_node",
            )

            self.graph.add_node(
                node_id=graph_node_id,
                node_type="cfg_node",
                name=str(node_type),
                line=line,
                function_id=function_id,
                metadata={
                    "cfg_node_id": node_id,
                    "cfg_type": node_type,
                },
            )

            self.graph.add_edge(
                function_id,
                graph_node_id,
                CodeGraphEdgeType.HAS_CFG_NODE,
            )

        # CFG edges
        for cfg_node in nodes:

            source_id = self._safe_get(
                cfg_node,
                "id",
            )

            if source_id is None:
                continue

            graph_source = (
                f"{function_id}::cfg::{source_id}"
            )

            successors = []

            get_successors = getattr(
                cfg,
                "get_successors",
                None,
            )

            if callable(get_successors):

                successors = get_successors(
                    source_id
                )

            elif hasattr(cfg_node, "successors"):

                successors = (
                    getattr(
                        cfg_node,
                        "successors",
                        [],
                    )
                    or []
                )

            for target_id in successors:

                graph_target = (
                    f"{function_id}::cfg::{target_id}"
                )

                if graph_target not in self.graph.nodes:
                    continue

                self.graph.add_edge(
                    graph_source,
                    graph_target,
                    CodeGraphEdgeType.CONTROL_FLOW,
                )

    # --------------------------------------------------------
    # Call Graph
    # --------------------------------------------------------

    def add_call_graph(
        self,
        call_graph: Any,
    ) -> None:
        """
        Add CALLS edges.
        """

        if call_graph is None:
            return

        get_edges = getattr(
            call_graph,
            "get_edges",
            None,
        )

        if callable(get_edges):

            for caller, callee in get_edges():

                self._ensure_function_node(caller)
                self._ensure_function_node(callee)

                self.graph.add_edge(
                    caller,
                    callee,
                    CodeGraphEdgeType.CALLS,
                )

            return

        calls = self._safe_get(
            call_graph,
            "calls",
            {},
        )

        if isinstance(calls, dict):

            for caller, callees in calls.items():

                self._ensure_function_node(caller)

                for callee in callees:

                    self._ensure_function_node(callee)

                    self.graph.add_edge(
                        caller,
                        callee,
                        CodeGraphEdgeType.CALLS,
                    )

    # --------------------------------------------------------
    # Dependency Graph
    # --------------------------------------------------------

    def add_dependency_graph(
        self,
        dependency_graph: Any,
    ) -> None:
        """
        Add dependency nodes and DEPENDS_ON edges.

        Supports the existing DependencyGraph implementation.
        """

        if dependency_graph is None:
            return

        nodes = self._safe_get(
            dependency_graph,
            "nodes",
            [],
        )

        for node in nodes:

            if isinstance(node, dict):

                node_id = node.get("id")

                if node_id is None:
                    continue

                node_type = node.get(
                    "type",
                    "file",
                )

                metadata = dict(node)

                metadata.pop("id", None)
                metadata.pop("type", None)

                self.graph.add_node(
                    node_id=node_id,
                    node_type=node_type,
                    name=node.get(
                        "name",
                        node_id,
                    ),
                    file=node.get(
                        "file",
                    ),
                    line=node.get(
                        "line",
                    ),
                    metadata=metadata,
                )

        edges = self._safe_get(
            dependency_graph,
            "edges",
            [],
        )

        for edge in edges:

            if isinstance(edge, dict):

                source = edge.get("source")
                target = edge.get("target")
                edge_type = edge.get(
                    "type",
                    "import",
                )

            else:

                continue

            if source is None or target is None:
                continue

            self._ensure_generic_node(source)
            self._ensure_generic_node(target)

            self.graph.add_edge(
                source,
                target,
                CodeGraphEdgeType.DEPENDS_ON,
                metadata={
                    "original_type": edge_type,
                },
            )

    # --------------------------------------------------------
    # Data Flow
    # --------------------------------------------------------

    def add_data_flow(
        self,
        function_id: str,
        data_flow: Any,
    ) -> None:
        """
        Add definitions and uses discovered by DataFlowAnalyzer.
        """

        if data_flow is None:
            return

        self._ensure_function_node(function_id)

        definitions = self._safe_get(
            data_flow,
            "definitions",
            [],
        )

        for index, definition in enumerate(
            definitions
        ):

            name = self._safe_get(
                definition,
                "name",
                f"variable_{index}",
            )

            line = self._safe_get(
                definition,
                "line",
            )

            definition_id = self._safe_get(
                definition,
                "id",
            )

            if definition_id is None:

                definition_id = (
                    f"D{index}"
                )

            node_id = (
                f"{function_id}::definition::{definition_id}"
            )

            self.graph.add_node(
                node_id=node_id,
                node_type="definition",
                name=name,
                line=line,
                function_id=function_id,
                metadata={
                    "definition_id": definition_id,
                    "kind": self._safe_get(
                        definition,
                        "kind",
                    ),
                },
            )

            self.graph.add_edge(
                function_id,
                node_id,
                CodeGraphEdgeType.DEFINES,
            )

        uses = self._safe_get(
            data_flow,
            "uses",
            [],
        )

        for index, use in enumerate(uses):

            name = self._safe_get(
                use,
                "name",
                f"variable_{index}",
            )

            line = self._safe_get(
                use,
                "line",
            )

            use_id = self._safe_get(
                use,
                "id",
            )

            if use_id is None:

                use_id = (
                    f"U{index}"
                )

            node_id = (
                f"{function_id}::use::{use_id}"
            )

            self.graph.add_node(
                node_id=node_id,
                node_type="use",
                name=name,
                line=line,
                function_id=function_id,
                metadata={
                    "use_id": use_id,
                    "context": self._safe_get(
                        use,
                        "context",
                    ),
                },
            )

            self.graph.add_edge(
                function_id,
                node_id,
                CodeGraphEdgeType.USES,
            )

    # --------------------------------------------------------
    # Def-Use
    # --------------------------------------------------------

    def add_def_use(
        self,
        function_id: str,
        def_use_result: Any,
    ) -> None:
        """
        Add DEF_USE relationships.
        """

        if def_use_result is None:
            return

        chains = self._safe_get(
            def_use_result,
            "chains",
            [],
        )

        for chain in chains:

            definition_id = self._safe_get(
                chain,
                "definition_id",
            )

            use_id = self._safe_get(
                chain,
                "use_id",
            )

            if (
                definition_id is None
                or use_id is None
            ):
                continue

            definition_node = (
                f"{function_id}::definition::{definition_id}"
            )

            use_node = (
                f"{function_id}::use::{use_id}"
            )

            if (
                definition_node not in
                self.graph.nodes
            ):
                self.graph.add_node(
                    definition_node,
                    "definition",
                    name=self._safe_get(
                        chain,
                        "variable",
                    ),
                    line=self._safe_get(
                        chain,
                        "definition_line",
                    ),
                    function_id=function_id,
                )

            if (
                use_node not in
                self.graph.nodes
            ):
                self.graph.add_node(
                    use_node,
                    "use",
                    name=self._safe_get(
                        chain,
                        "variable",
                    ),
                    line=self._safe_get(
                        chain,
                        "use_line",
                    ),
                    function_id=function_id,
                )

            self.graph.add_edge(
                definition_node,
                use_node,
                CodeGraphEdgeType.DEF_USE,
                metadata={
                    "variable": self._safe_get(
                        chain,
                        "variable",
                    ),
                    "definition_kind": self._safe_get(
                        chain,
                        "definition_kind",
                    ),
                    "use_context": self._safe_get(
                        chain,
                        "use_context",
                    ),
                },
            )

    # --------------------------------------------------------
    # Taint
    # --------------------------------------------------------

    def add_taint_edges(
        self,
        taint_results: Any,
    ) -> None:
        """
        Add TAINT_FLOW relationships when the existing taint
        analyzer exposes source/sink relationships.

        This method intentionally supports multiple result formats.
        """

        if taint_results is None:
            return

        if isinstance(taint_results, dict):

            iterable = taint_results.values()

        elif isinstance(taint_results, (list, tuple)):

            iterable = taint_results

        else:

            iterable = [taint_results]

        for result in iterable:

            flows = self._safe_get(
                result,
                "flows",
                [],
            )

            for flow in flows:

                source = self._safe_get(
                    flow,
                    "source",
                )

                target = self._safe_get(
                    flow,
                    "sink",
                )

                if source is None or target is None:
                    continue

                self._ensure_generic_node(source)
                self._ensure_generic_node(target)

                self.graph.add_edge(
                    source,
                    target,
                    CodeGraphEdgeType.TAINT_FLOW,
                )

    # --------------------------------------------------------
    # Full Build
    # --------------------------------------------------------

    def build(
        self,
        *,
        control_flow_graphs: dict[str, Any] | None = None,
        call_graph: Any = None,
        dependency_graph: Any = None,
        data_flow_results: dict[str, Any] | None = None,
        def_use_results: dict[str, Any] | None = None,
        taint_results: Any = None,
    ) -> UnifiedCodeGraph:
        """
        Build the unified graph.

        Parameters are intentionally optional so individual
        analysis stages can be introduced incrementally.
        """

        self.graph = UnifiedCodeGraph()

        control_flow_graphs = (
            control_flow_graphs or {}
        )

        data_flow_results = (
            data_flow_results or {}
        )

        def_use_results = (
            def_use_results or {}
        )

        # ----------------------------------------------------
        # Functions + CFG + data flow
        # ----------------------------------------------------

        for function_id, cfg in (
            control_flow_graphs.items()
        ):

            function_name = (
                self._safe_get(
                    cfg,
                    "function_name",
                    function_id,
                )
            )

            self.add_function(
                function_id=function_id,
                function_name=function_name,
            )

            self.add_cfg(
                function_id,
                cfg,
            )

            if function_id in data_flow_results:

                self.add_data_flow(
                    function_id,
                    data_flow_results[
                        function_id
                    ],
                )

            if function_id in def_use_results:

                self.add_def_use(
                    function_id,
                    def_use_results[
                        function_id
                    ],
                )

        # ----------------------------------------------------
        # Call graph
        # ----------------------------------------------------

        self.add_call_graph(
            call_graph
        )

        # ----------------------------------------------------
        # Dependency graph
        # ----------------------------------------------------

        self.add_dependency_graph(
            dependency_graph
        )

        # ----------------------------------------------------
        # Taint
        # ----------------------------------------------------

        self.add_taint_edges(
            taint_results
        )

        return self.graph

    # --------------------------------------------------------
    # Internal helpers
    # --------------------------------------------------------

    def _ensure_function_node(
        self,
        function_id: str,
    ) -> None:
        """
        Create a function node if it doesn't exist.
        """

        if function_id not in self.graph.nodes:

            self.graph.add_node(
                node_id=function_id,
                node_type="function",
                name=function_id,
                function_id=function_id,
            )

    def _ensure_generic_node(
        self,
        node_id: str,
    ) -> None:
        """
        Create a generic node if it doesn't exist.
        """

        if node_id not in self.graph.nodes:

            self.graph.add_node(
                node_id=node_id,
                node_type="unknown",
                name=node_id,
            )