from __future__ import annotations

from pathlib import Path

from backend.analysis.call_graph import CallGraphAnalyzer
from backend.analysis.cfg import CFGAnalyzer
from backend.analysis.data_flow import DataFlowAnalyzer
from backend.analysis.dead_definitions import DeadDefinitionAnalyzer
from backend.analysis.def_use import DefUseAnalyzer
from backend.analysis.function_collector import FunctionCollector
from backend.analysis.metrics import MetricsAnalyzer
from backend.analysis.reaching_definitions import (
    ReachingDefinitionsAnalyzer,
)
from backend.analysis.risk_labels import RiskLabelGenerator
from backend.analysis.unified_code_graph import (
    UnifiedCodeGraph,
    UnifiedCodeGraphBuilder,
)
from backend.analysis.use_before_definition import (
    UseBeforeDefinitionAnalyzer,
)
from backend.models.analysis_result import AnalysisResult
from backend.parsing.ast_parser import ASTParser, CodeExtractor
from backend.repository.manager import RepositoryManager


class ProjectAnalyzer:
    """
    Analyze all supported source files in a repository.

    Analysis pipeline:

        Repository
            ↓
        AST
            ↓
        Metrics
            ↓
        Function Collection
            ↓
        CFG
            ↓
        Data Flow
            ↓
        Reaching Definitions
            ↓
        Def-Use
            ↓
        Use-Before-Definition
            ↓
        Dead Definitions
            ↓
        Call Graph
            ↓
        Unified Code Graph
    """

    def __init__(self, repository_path: str | Path):
        self.repository_manager = RepositoryManager(
            repository_path
        )

        self.errors: list[str] = []

        # -----------------------------------------------------
        # Repository-level Call Graph
        # -----------------------------------------------------

        self.call_graph = None

        # -----------------------------------------------------
        # Repository-level CFGs
        #
        # function_id -> ControlFlowGraph
        # -----------------------------------------------------

        self.control_flow_graphs = {}

        # -----------------------------------------------------
        # Function AST nodes
        #
        # function_id -> AST FunctionDef / AsyncFunctionDef
        # -----------------------------------------------------

        self.functions = {}

        # -----------------------------------------------------
        # Data Flow
        #
        # function_id -> DataFlowResult
        # -----------------------------------------------------

        self.data_flow_results = {}

        # -----------------------------------------------------
        # Reaching Definitions
        #
        # function_id -> ReachingDefinitionsResult
        # -----------------------------------------------------

        self.reaching_definitions = {}

        # -----------------------------------------------------
        # Def-Use
        #
        # function_id -> DefUseResult
        # -----------------------------------------------------

        self.def_use_results = {}

        # -----------------------------------------------------
        # Use-Before-Definition
        #
        # function_id -> UseBeforeDefinitionResult
        # -----------------------------------------------------

        self.use_before_definition = {}

        # -----------------------------------------------------
        # Dead Definitions
        #
        # function_id -> DeadDefinitionResult
        # -----------------------------------------------------

        self.dead_definitions = {}

        # -----------------------------------------------------
        # Unified Code Graph
        # -----------------------------------------------------

        self.unified_code_graph: UnifiedCodeGraph | None = None

    # =========================================================
    # MAIN ANALYSIS
    # =========================================================

    def analyze(self) -> list[AnalysisResult]:
        """
        Analyze the complete repository.
        """

        self._reset_analysis_state()

        results: list[AnalysisResult] = []

        trees = {}

        root = (
            self.repository_manager
            .repository_path
            .resolve()
        )

        # -----------------------------------------------------
        # PASS 1
        #
        # Parse files
        # Extract structure
        # Calculate metrics
        # Collect functions
        # Build CFG
        # -----------------------------------------------------

        for file_path in (
            self.repository_manager.get_python_files()
        ):

            try:

                tree = ASTParser(file_path).parse()

            except ValueError as exc:

                self.errors.append(str(exc))

                continue

            # -------------------------------------------------
            # Repository-relative path
            # -------------------------------------------------

            relative_path = (
                file_path.resolve()
                .relative_to(root)
                .as_posix()
            )

            # Keep AST trees for repository-level analysis.

            trees[relative_path] = tree

            # -------------------------------------------------
            # AST extraction
            # -------------------------------------------------

            extractor = CodeExtractor()

            extractor.visit(tree)

            result = extractor.get_result(
                file_path
            )

            # -------------------------------------------------
            # Metrics
            # -------------------------------------------------

            metrics_analyzer = MetricsAnalyzer()

            metrics_analyzer.visit(tree)

            result.metrics = (
                metrics_analyzer.metrics
            )

            # -------------------------------------------------
            # Function collection
            # -------------------------------------------------

            function_collector = FunctionCollector(
                relative_path
            )

            function_collector.visit(tree)

            # Save function AST nodes.

            self.functions.update(
                function_collector.functions
            )

            # -------------------------------------------------
            # CFG
            # -------------------------------------------------

            cfg_analyzer = CFGAnalyzer()

            for (
                function_id,
                function_node,
            ) in function_collector.functions.items():

                cfg = cfg_analyzer.analyze(
                    function_node
                )

                self.control_flow_graphs[
                    function_id
                ] = cfg

            results.append(result)

        # -----------------------------------------------------
        # PASS 2
        #
        # Data Flow
        # Reaching Definitions
        # Def-Use
        # Use-Before-Definition
        # Dead Definitions
        # -----------------------------------------------------

        self._run_data_flow_analysis()

        # -----------------------------------------------------
        # PASS 3
        #
        # Repository Call Graph
        # -----------------------------------------------------

        if trees:

            call_graph_analyzer = (
                CallGraphAnalyzer()
            )

            self.call_graph = (
                call_graph_analyzer.analyze(
                    trees
                )
            )

        # -----------------------------------------------------
        # PASS 4
        #
        # Unified Code Graph
        # -----------------------------------------------------

        self._build_unified_code_graph()

        return results

    # =========================================================
    # RESET
    # =========================================================

    def _reset_analysis_state(self) -> None:
        """
        Reset all analysis state before a new analysis run.
        """

        self.errors = []

        self.call_graph = None

        self.control_flow_graphs = {}

        self.functions = {}

        self.data_flow_results = {}

        self.reaching_definitions = {}

        self.def_use_results = {}

        self.use_before_definition = {}

        self.dead_definitions = {}

        self.unified_code_graph = None

    # =========================================================
    # DATA FLOW PIPELINE
    # =========================================================

    def _run_data_flow_analysis(self) -> None:
        """
        Run all intra-procedural data-flow analyses.
        """

        data_flow_analyzer = (
            DataFlowAnalyzer()
        )

        reaching_definitions_analyzer = (
            ReachingDefinitionsAnalyzer()
        )

        def_use_analyzer = (
            DefUseAnalyzer()
        )

        use_before_definition_analyzer = (
            UseBeforeDefinitionAnalyzer()
        )

        dead_definition_analyzer = (
            DeadDefinitionAnalyzer()
        )

        # -----------------------------------------------------
        # Function-by-function analysis
        # -----------------------------------------------------

        for (
            function_id,
            function_node,
        ) in self.functions.items():

            cfg = self.control_flow_graphs.get(
                function_id
            )

            if cfg is None:

                continue

            # -------------------------------------------------
            # Build source-line -> CFG-node mapping
            # -------------------------------------------------

            cfg_node_map = (
                self._build_cfg_node_map(cfg)
            )

            # -------------------------------------------------
            # Data Flow
            # -------------------------------------------------

            data_flow = (
                data_flow_analyzer.analyze(
                    function_node=function_node,
                    function_id=function_id,
                    cfg_node_map=cfg_node_map,
                )
            )

            self.data_flow_results[
                function_id
            ] = data_flow

            # -------------------------------------------------
            # Reaching Definitions
            # -------------------------------------------------

            reaching = (
                reaching_definitions_analyzer.analyze(
                    cfg=cfg,
                    data_flow=data_flow,
                )
            )

            self.reaching_definitions[
                function_id
            ] = reaching

            # -------------------------------------------------
            # Def-Use
            # -------------------------------------------------

            def_use = (
                def_use_analyzer.analyze(
                    data_flow=data_flow,
                    reaching_definitions=reaching,
                )
            )

            self.def_use_results[
                function_id
            ] = def_use

            # -------------------------------------------------
            # Use-Before-Definition
            # -------------------------------------------------

            use_before = (
                use_before_definition_analyzer.analyze(
                    data_flow=data_flow,
                    reaching_definitions=reaching,
                )
            )

            self.use_before_definition[
                function_id
            ] = use_before

            # -------------------------------------------------
            # Dead Definitions
            # -------------------------------------------------

            dead = (
                dead_definition_analyzer.analyze(
                    reaching_definitions=reaching,
                    def_use=def_use,
                )
            )

            self.dead_definitions[
                function_id
            ] = dead

    # =========================================================
    # CFG NODE MAP
    # =========================================================

    @staticmethod
    def _build_cfg_node_map(
        cfg,
    ) -> dict[int, list[int]]:
        """
        Build:

            source line -> CFG node IDs

        Example:

            {
                2: [1],
                3: [2],
                4: [3]
            }

        This allows DataFlowAnalyzer to associate
        definitions and uses with CFG nodes.
        """

        mapping: dict[int, list[int]] = {}

        for node in cfg.get_nodes():

            line = node.line

            if line is None:

                continue

            mapping.setdefault(
                line,
                [],
            ).append(
                node.id
            )

        return mapping

    # =========================================================
    # UNIFIED CODE GRAPH
    # =========================================================

    def _build_unified_code_graph(
        self,
    ) -> None:
        """
        Combine all existing analysis results into
        one UnifiedCodeGraph.
        """

        builder = (
            UnifiedCodeGraphBuilder()
        )

        # -----------------------------------------------------
        # Add functions + files + CFG + data flow + def-use
        # -----------------------------------------------------

        for (
            function_id,
            function_node,
        ) in self.functions.items():

            cfg = self.control_flow_graphs.get(
                function_id
            )

            # Extract file path from function ID.

            file_path = function_id.split(
                "::",
                1,
            )[0]

            function_name = getattr(
                function_node,
                "name",
                function_id,
            )

            line = getattr(
                function_node,
                "lineno",
                None,
            )

            # Function node

            builder.add_function(
                function_id=function_id,
                file_path=file_path,
                function_name=function_name,
                line=line,
            )

            # CFG

            if cfg is not None:

                builder.add_cfg(
                    function_id=function_id,
                    cfg=cfg,
                )

            # Data Flow

            data_flow = (
                self.data_flow_results.get(
                    function_id
                )
            )

            if data_flow is not None:

                builder.add_data_flow(
                    function_id=function_id,
                    data_flow=data_flow,
                )

            # Def-Use

            def_use = (
                self.def_use_results.get(
                    function_id
                )
            )

            if def_use is not None:

                builder.add_def_use(
                    function_id=function_id,
                    def_use_result=def_use,
                )

        # -----------------------------------------------------
        # Call Graph
        # -----------------------------------------------------

        if self.call_graph is not None:

            builder.add_call_graph(
                self.call_graph
            )

        # -----------------------------------------------------
        # Save graph
        # -----------------------------------------------------

        self.unified_code_graph = (
            builder.graph
        )
    def generate_risk_labels(self):
        """
        Generate explainable weak-risk labels from the
        UnifiedCodeGraph produced by the analyzer.

        analyze() must be called before this method.
        """

        if self.unified_code_graph is None:
            raise RuntimeError(
                "Unified code graph has not been built. "
                "Call analyze() before generating risk labels."
            )

        generator = RiskLabelGenerator(
            self.unified_code_graph
        )

        return generator.generate()