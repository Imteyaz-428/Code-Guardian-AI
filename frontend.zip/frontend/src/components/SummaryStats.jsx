import { countByLevel } from "../utils/risk";

function SummaryStats({ summary, findings }) {
  const stats = [
    {
      label: "Files",
      value: summary.files_analyzed,
      description: "analyzed",
    },
    {
      label: "Functions",
      value: summary.functions_analyzed,
      description: "detected",
    },
    {
      label: "High Risk",
      value: countByLevel(findings, "HIGH"),
      description: "findings",
      emphasis: "high",
    },
    {
      label: "Medium Risk",
      value: countByLevel(findings, "MEDIUM"),
      description: "findings",
      emphasis: "medium",
    },
  ];

  return (
    <section className="summary-grid">
      {stats.map((stat) => (
        <div
          className={`summary-card ${stat.emphasis ? `summary-${stat.emphasis}` : ""}`}
          key={stat.label}
        >
          <span>{stat.label}</span>

          <strong>{stat.value}</strong>

          <small>{stat.description}</small>
        </div>
      ))}
    </section>
  );
}

export default SummaryStats;